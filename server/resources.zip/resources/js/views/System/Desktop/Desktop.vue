<template>
  <div />
</template>
<script>
  export default {
    name: 'Desktop',
  };
</script>

<style scoped></style>
