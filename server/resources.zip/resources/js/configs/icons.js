export default [
  // Community Material Design Icons | http://materialdesignicons.com/
  'https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css',
];
