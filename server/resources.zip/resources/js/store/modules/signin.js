let mode = 'transfer' 
console.log(mode);
