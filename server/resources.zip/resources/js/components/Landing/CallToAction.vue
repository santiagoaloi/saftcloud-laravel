<template>
  <v-container class="py-8">
    <div class="d-flex flex-column flex-lg-row justify-space-between align-center">
      <div class="text-center text-lg-left">
        <div class="text-h3">Ready to talk?</div>
        <div class="text-h3 secondary--text">Our team is here to help.</div>
      </div>
      <div class="mt-4 mt-lg-0">
        <v-btn x-large class="my-1 mx-sm-2 w-full w-sm-auto" color="primary"> Contact Sales </v-btn>
        <v-btn x-large class="my-1 w-full w-sm-auto"> Learn more </v-btn>
      </div>
    </div>
  </v-container>
</template>
