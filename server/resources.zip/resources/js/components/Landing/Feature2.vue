<template>
  <v-container>
    <div data-aos="fade-up">
      <v-card class="pa-10 cursor-pointer" width="100%">
        <v-row align="center">
          <v-col cols="12" lg="6">
            <div class="text-uppercase body-2 primary--text mb-2 mt-0 mt-xl-10">
              Organize your products and sale workflows
            </div>
            <h2>Get your startup ready for business</h2>
            <div class="text-h6 mt-5">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus impedit error labore
              doloremque fugit! Dolor fugit molestiae vero quos quisquam nobis, eos debitis magni
              omnis ea incidunt amet voluptate dignissimos!
            </div>
          </v-col>
        </v-row>
      </v-card>
    </div>
  </v-container>
</template>

<script>
  export default {
    name: 'Feature2',
  };
</script>
