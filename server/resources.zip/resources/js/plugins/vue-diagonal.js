import Vue from 'vue';
import VueDiagonal from 'vue-diagonal';

Vue.component('VueDiagonal', VueDiagonal);
