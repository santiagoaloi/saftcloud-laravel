document.addEventListener(
  'contextmenu',
  (e) => {
    e.preventDefault();
  },
  false,
);
