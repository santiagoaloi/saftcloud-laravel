import Vue from 'vue';
import Vidle from 'v-idle';

Vue.use(Vidle);
