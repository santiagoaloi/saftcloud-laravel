import Vue from 'vue';
import VueLazyInput from 'vue-lazy-input';

Vue.use(VueLazyInput);
